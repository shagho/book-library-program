/****************************************************************************
** Meta object code from reading C++ file 'dialog1.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.11.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../Project1/dialog1.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'dialog1.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.11.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Dialog1_t {
    QByteArrayData data[21];
    char stringdata0[293];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Dialog1_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Dialog1_t qt_meta_stringdata_Dialog1 = {
    {
QT_MOC_LITERAL(0, 0, 7), // "Dialog1"
QT_MOC_LITERAL(1, 8, 6), // "showD2"
QT_MOC_LITERAL(2, 15, 0), // ""
QT_MOC_LITERAL(3, 16, 1), // "r"
QT_MOC_LITERAL(4, 18, 1), // "c"
QT_MOC_LITERAL(5, 20, 1), // "d"
QT_MOC_LITERAL(6, 22, 13), // "long long int"
QT_MOC_LITERAL(7, 36, 9), // "showTable"
QT_MOC_LITERAL(8, 46, 7), // "AddRows"
QT_MOC_LITERAL(9, 54, 13), // "RemoveAllRows"
QT_MOC_LITERAL(10, 68, 24), // "on_tableWidget_activated"
QT_MOC_LITERAL(11, 93, 11), // "QModelIndex"
QT_MOC_LITERAL(12, 105, 5), // "index"
QT_MOC_LITERAL(13, 111, 23), // "on_pushButton_2_clicked"
QT_MOC_LITERAL(14, 135, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(15, 157, 20), // "on_sort_book_clicked"
QT_MOC_LITERAL(16, 178, 22), // "on_sort_writer_clicked"
QT_MOC_LITERAL(17, 201, 21), // "on_sort_genre_clicked"
QT_MOC_LITERAL(18, 223, 20), // "on_sort_year_clicked"
QT_MOC_LITERAL(19, 244, 22), // "on_sort_serial_clicked"
QT_MOC_LITERAL(20, 267, 25) // "on_sort_publisher_clicked"

    },
    "Dialog1\0showD2\0\0r\0c\0d\0long long int\0"
    "showTable\0AddRows\0RemoveAllRows\0"
    "on_tableWidget_activated\0QModelIndex\0"
    "index\0on_pushButton_2_clicked\0"
    "on_pushButton_clicked\0on_sort_book_clicked\0"
    "on_sort_writer_clicked\0on_sort_genre_clicked\0"
    "on_sort_year_clicked\0on_sort_serial_clicked\0"
    "on_sort_publisher_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Dialog1[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    3,   89,    2, 0x0a /* Public */,
       1,    3,   96,    2, 0x0a /* Public */,
       1,    3,  103,    2, 0x0a /* Public */,
       7,    0,  110,    2, 0x0a /* Public */,
       8,    1,  111,    2, 0x0a /* Public */,
       9,    0,  114,    2, 0x0a /* Public */,
      10,    1,  115,    2, 0x08 /* Private */,
      13,    0,  118,    2, 0x08 /* Private */,
      14,    0,  119,    2, 0x08 /* Private */,
      15,    0,  120,    2, 0x08 /* Private */,
      16,    0,  121,    2, 0x08 /* Private */,
      17,    0,  122,    2, 0x08 /* Private */,
      18,    0,  123,    2, 0x08 /* Private */,
      19,    0,  124,    2, 0x08 /* Private */,
      20,    0,  125,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int,    3,    4,    5,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::QString,    3,    4,    5,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, 0x80000000 | 6,    3,    4,    5,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 11,   12,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void Dialog1::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Dialog1 *_t = static_cast<Dialog1 *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->showD2((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 1: _t->showD2((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 2: _t->showD2((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< long long int(*)>(_a[3]))); break;
        case 3: _t->showTable(); break;
        case 4: _t->AddRows((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->RemoveAllRows(); break;
        case 6: _t->on_tableWidget_activated((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 7: _t->on_pushButton_2_clicked(); break;
        case 8: _t->on_pushButton_clicked(); break;
        case 9: _t->on_sort_book_clicked(); break;
        case 10: _t->on_sort_writer_clicked(); break;
        case 11: _t->on_sort_genre_clicked(); break;
        case 12: _t->on_sort_year_clicked(); break;
        case 13: _t->on_sort_serial_clicked(); break;
        case 14: _t->on_sort_publisher_clicked(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject Dialog1::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_Dialog1.data,
      qt_meta_data_Dialog1,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *Dialog1::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Dialog1::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Dialog1.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "nash_Borrowing"))
        return static_cast< nash_Borrowing*>(this);
    return QDialog::qt_metacast(_clname);
}

int Dialog1::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 15;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
